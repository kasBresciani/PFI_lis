from app import app # Importa a classe principal do programa

if __name__ == '__main__': # Identifica se é o arquivo principal (main.py)
    app.run(debug = True)  # Executa a aplicação em modo debug