UPDATE usuarios
SET adm = 1
WHERE (email = 'lismariafg203adm@gmail.com'); # Insira o email do usuário administrador aqui